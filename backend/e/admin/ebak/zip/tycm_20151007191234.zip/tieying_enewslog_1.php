<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `tieying_enewslog`;");
E_C("CREATE TABLE `tieying_enewslog` (
  `loginid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginip` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(30) NOT NULL DEFAULT '',
  `loginauth` tinyint(1) NOT NULL DEFAULT '0',
  `ipport` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`loginid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=gbk");
E_D("replace into `tieying_enewslog` values('1','admin','2015-05-24 17:27:28','183.206.169.207','1','','0','33668');");
E_D("replace into `tieying_enewslog` values('2','admin','2015-05-24 20:37:04','183.206.169.207','1','','0','52668');");
E_D("replace into `tieying_enewslog` values('3','admin','2015-05-25 17:04:02','183.206.169.207','1','','0','45740');");
E_D("replace into `tieying_enewslog` values('4','admin','2015-05-26 09:01:11','183.206.173.70','1','','0','56057');");
E_D("replace into `tieying_enewslog` values('5','admin','2015-05-27 09:06:10','183.206.173.70','1','','0','29717');");
E_D("replace into `tieying_enewslog` values('6','admin','2015-05-27 17:14:57','183.206.173.70','0','','0','13999');");
E_D("replace into `tieying_enewslog` values('7','admin','2015-05-27 17:15:26','183.206.173.70','1','','0','14384');");
E_D("replace into `tieying_enewslog` values('8','admin','2015-05-27 21:50:51','183.206.162.211','1','','0','32076');");
E_D("replace into `tieying_enewslog` values('9','admin','2015-05-29 20:42:39','183.206.168.97','1','','0','56752');");
E_D("replace into `tieying_enewslog` values('10','admin','2015-05-29 21:22:17','183.206.168.97','1','','0','15017');");
E_D("replace into `tieying_enewslog` values('11','admin','2015-05-31 11:30:06','183.206.168.167','1','','0','60371');");
E_D("replace into `tieying_enewslog` values('12','admin','2015-06-01 10:23:29','49.65.132.18','1','','0','51360');");
E_D("replace into `tieying_enewslog` values('13','admin','2015-06-02 13:51:38','183.206.163.136','1','','0','55906');");
E_D("replace into `tieying_enewslog` values('14','admin','2015-06-05 00:15:33','183.206.173.170','1','','0','21390');");
E_D("replace into `tieying_enewslog` values('15','admin','2015-06-05 14:26:00','183.206.173.170','1','','0','56324');");
E_D("replace into `tieying_enewslog` values('16','admin','2015-06-05 21:20:31','183.206.162.3','1','','0','5508');");
E_D("replace into `tieying_enewslog` values('17','admin','2015-06-06 14:36:40','183.206.162.3','1','','0','52500');");
E_D("replace into `tieying_enewslog` values('18','admin','2015-06-07 08:37:40','183.206.162.3','1','','0','4362');");
E_D("replace into `tieying_enewslog` values('19','admin','2015-06-07 16:57:09','183.206.162.3','1','','0','12726');");
E_D("replace into `tieying_enewslog` values('20','admin','2015-06-08 09:18:27','183.206.168.208','1','','0','1226');");
E_D("replace into `tieying_enewslog` values('21','admin','2015-06-08 18:52:05','183.206.168.208','1','','0','39998');");
E_D("replace into `tieying_enewslog` values('22','admin','2015-06-08 22:18:42','183.206.168.208','1','','0','64244');");
E_D("replace into `tieying_enewslog` values('23','admin','2015-06-10 01:32:22','183.206.162.37','1','','0','22750');");
E_D("replace into `tieying_enewslog` values('24','admin','2015-06-11 04:51:32','183.206.165.45','1','','0','31662');");
E_D("replace into `tieying_enewslog` values('25','admin','2015-06-12 22:41:48','180.110.19.156','1','','0','38488');");
E_D("replace into `tieying_enewslog` values('26','admin','2015-06-14 15:27:20','183.206.164.79','1','','0','62249');");
E_D("replace into `tieying_enewslog` values('27','admin','2015-07-24 02:55:06','221.178.200.4','1','','0','7991');");
E_D("replace into `tieying_enewslog` values('28','admin','2015-07-24 11:46:53','221.178.200.4','1','','0','42112');");
E_D("replace into `tieying_enewslog` values('29','admin','2015-07-25 14:02:22','221.178.200.24','1','','0','4289');");
E_D("replace into `tieying_enewslog` values('30','admin','2015-07-26 09:02:07','221.178.200.24','1','','0','25736');");
E_D("replace into `tieying_enewslog` values('31','admin','2015-07-26 10:28:43','221.178.200.24','1','','0','28911');");
E_D("replace into `tieying_enewslog` values('32','admin','2015-07-26 12:17:37','221.178.200.24','1','','0','34313');");
E_D("replace into `tieying_enewslog` values('33','admin','2015-07-26 15:44:36','221.178.200.24','1','','0','36502');");
E_D("replace into `tieying_enewslog` values('34','admin','2015-07-26 18:19:31','221.178.200.24','1','','0','51126');");
E_D("replace into `tieying_enewslog` values('35','admin','2015-07-26 18:27:12','221.178.200.24','1','','0','50209');");
E_D("replace into `tieying_enewslog` values('36','admin','2015-07-26 18:47:48','49.74.241.245','1','','0','53604');");
E_D("replace into `tieying_enewslog` values('37','admin','2015-07-27 12:32:43','49.74.241.245','1','','0','54178');");
E_D("replace into `tieying_enewslog` values('38','admin','2015-07-28 15:18:00','180.110.135.247','1','','0','51725');");
E_D("replace into `tieying_enewslog` values('39','admin','2015-07-29 12:54:48','180.110.18.75','1','','0','50184');");
E_D("replace into `tieying_enewslog` values('40','admin','2015-07-29 15:21:09','180.110.18.75','1','','0','52383');");
E_D("replace into `tieying_enewslog` values('41','admin','2015-07-29 17:46:34','114.221.20.201','1','','0','26907');");
E_D("replace into `tieying_enewslog` values('42','admin','2015-07-29 18:06:03','114.221.20.201','1','','0','26736');");
E_D("replace into `tieying_enewslog` values('43','admin','2015-07-29 22:44:50','218.94.110.187','1','','0','33757');");
E_D("replace into `tieying_enewslog` values('44','admin','2015-07-29 22:54:06','218.94.110.187','1','','0','1464');");
E_D("replace into `tieying_enewslog` values('45','admin','2015-08-01 19:14:06','221.178.200.35','1','','0','14645');");
E_D("replace into `tieying_enewslog` values('46','admin','2015-08-02 07:01:58','221.178.200.35','1','','0','21246');");
E_D("replace into `tieying_enewslog` values('47','admin','2015-08-02 08:20:26','221.178.200.35','1','','0','58048');");
E_D("replace into `tieying_enewslog` values('48','admin','2015-08-02 08:24:53','221.178.200.35','1','','0','49276');");
E_D("replace into `tieying_enewslog` values('49','admin','2015-08-05 13:50:41','221.178.200.30','1','','0','44996');");
E_D("replace into `tieying_enewslog` values('50','admin','2015-08-05 14:17:59','221.178.200.30','1','','0','55668');");
E_D("replace into `tieying_enewslog` values('51','admin','2015-08-10 11:19:29','180.111.28.3','1','','0','56459');");
E_D("replace into `tieying_enewslog` values('52','admin','2015-09-09 05:14:56','221.178.200.19','1','','0','44408');");
E_D("replace into `tieying_enewslog` values('53','admin','2015-09-14 04:43:26','221.178.200.28','0','','1','27136');");
E_D("replace into `tieying_enewslog` values('54','admin','2015-09-14 04:43:45','221.178.200.28','1','','0','28269');");
E_D("replace into `tieying_enewslog` values('55','admin','2015-09-17 19:48:07','221.178.200.10','1','','0','19962');");
E_D("replace into `tieying_enewslog` values('56','admin','2015-09-18 00:28:16','221.178.200.10','1','','0','47712');");
E_D("replace into `tieying_enewslog` values('57','admin','2015-09-18 11:46:43','49.65.132.111','1','','0','52223');");
E_D("replace into `tieying_enewslog` values('58','admin','2015-09-18 11:48:10','221.178.200.10','1','','0','11850');");
E_D("replace into `tieying_enewslog` values('59','admin','2015-09-18 11:49:58','49.65.132.111','1','','0','52280');");
E_D("replace into `tieying_enewslog` values('60','admin','2015-09-18 11:50:35','221.178.200.10','1','','0','44646');");
E_D("replace into `tieying_enewslog` values('61','admin','2015-09-18 11:51:07','49.65.132.111','1','','0','52279');");
E_D("replace into `tieying_enewslog` values('62','admin','2015-09-18 11:51:27','221.178.200.10','1','','0','56378');");
E_D("replace into `tieying_enewslog` values('63','admin','2015-09-18 13:13:45','49.65.132.111','1','','0','55307');");
E_D("replace into `tieying_enewslog` values('64','admin','2015-09-19 05:59:50','117.136.20.149','0','','1','56534');");
E_D("replace into `tieying_enewslog` values('65','admin','2015-09-19 10:30:06','180.110.132.61','1','','0','50090');");
E_D("replace into `tieying_enewslog` values('66','admin','2015-09-19 15:45:43','180.110.132.61','1','','0','53969');");
E_D("replace into `tieying_enewslog` values('67','admin','2015-09-20 17:24:20','221.178.200.26','1','','0','9627');");
E_D("replace into `tieying_enewslog` values('68','admin','2015-09-20 22:56:37','221.178.200.26','1','','0','30906');");
E_D("replace into `tieying_enewslog` values('69','admin','2015-09-21 20:25:13','180.111.31.105','1','','0','63518');");
E_D("replace into `tieying_enewslog` values('70','admin','2015-09-22 09:34:30','221.178.200.26','1','','0','60806');");
E_D("replace into `tieying_enewslog` values('71','admin','2015-09-25 00:43:13','221.178.200.5','1','','0','21094');");
E_D("replace into `tieying_enewslog` values('72','admin','2015-09-25 00:47:04','221.178.200.5','1','','0','31487');");
E_D("replace into `tieying_enewslog` values('73','WangZhanAdmin','2015-09-29 11:23:54','221.178.200.29','0','','0','1487');");
E_D("replace into `tieying_enewslog` values('74','admin','2015-09-29 11:24:15','221.178.200.29','0','','0','6408');");
E_D("replace into `tieying_enewslog` values('75','admin','2015-09-29 11:26:21','221.178.200.29','1','','0','36585');");
E_D("replace into `tieying_enewslog` values('76','WangZhanAdmin','2015-10-01 17:53:07','221.178.200.39','0','','0','45495');");
E_D("replace into `tieying_enewslog` values('77','admin','2015-10-01 17:53:37','221.178.200.39','1','','0','52384');");
E_D("replace into `tieying_enewslog` values('78','admin','2015-10-01 17:54:29','221.178.200.39','1','','0','64344');");
E_D("replace into `tieying_enewslog` values('79','admin','2015-10-01 17:56:08','221.178.200.39','1','','0','22666');");
E_D("replace into `tieying_enewslog` values('80','admin','2015-10-01 18:16:52','221.178.200.39','1','','0','3705');");
E_D("replace into `tieying_enewslog` values('81','admin','2015-10-01 20:48:30','221.178.200.39','1','','0','19573');");
E_D("replace into `tieying_enewslog` values('82','admin','2015-10-01 20:48:58','175.0.202.68','1','','0','58475');");
E_D("replace into `tieying_enewslog` values('83','admin','2015-10-01 20:54:44','221.178.200.39','1','','0','19086');");
E_D("replace into `tieying_enewslog` values('84','admin','2015-10-01 21:31:16','175.0.202.68','1','','0','60384');");
E_D("replace into `tieying_enewslog` values('85','admin','2015-10-02 17:41:14','175.0.202.68','1','','0','56278');");
E_D("replace into `tieying_enewslog` values('86','admin','2015-10-02 23:39:18','221.178.200.39','1','','0','8455');");
E_D("replace into `tieying_enewslog` values('87','admin','2015-10-05 22:24:27','221.178.200.16','1','','0','59309');");
E_D("replace into `tieying_enewslog` values('88','admin','2015-10-06 11:30:27','221.178.200.16','1','','0','13318');");
E_D("replace into `tieying_enewslog` values('89','admin','2015-10-06 14:34:16','221.178.200.16','1','','0','63144');");
E_D("replace into `tieying_enewslog` values('90','admin','2015-10-07 09:22:02','221.178.200.36','1','','0','53720');");
E_D("replace into `tieying_enewslog` values('91','admin','2015-10-07 12:09:43','221.178.200.36','1','','0','64530');");
E_D("replace into `tieying_enewslog` values('92','admin','2015-10-07 16:13:58','221.178.200.36','1','','0','51144');");
E_D("replace into `tieying_enewslog` values('93','admin','2015-10-07 18:44:55','221.178.200.36','1','','0','16837');");

@include("../../inc/footer.php");
?>