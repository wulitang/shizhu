<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `tieying_enewspubvar`;");
E_C("CREATE TABLE `tieying_enewspubvar` (
  `varid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `myvar` varchar(60) NOT NULL DEFAULT '',
  `varname` varchar(20) NOT NULL DEFAULT '',
  `varvalue` text NOT NULL,
  `varsay` varchar(255) NOT NULL DEFAULT '',
  `myorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tocache` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`varid`),
  UNIQUE KEY `varname` (`varname`),
  KEY `classid` (`classid`),
  KEY `tocache` (`tocache`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=gbk");
E_D("replace into `tieying_enewspubvar` values('1','beianhao','������','��ICP��14022218��-1','','0','0','1');");
E_D("replace into `tieying_enewspubvar` values('2','banquansuoyou','��Ȩ����','��ӥ������ϰ��','','0','0','1');");
E_D("replace into `tieying_enewspubvar` values('3','icon','icon','/skin/tjxy/images/favicon.gif','','0','0','1');");
E_D("replace into `tieying_enewspubvar` values('4','kfqq','�ͷ�QQ','57029765','','0','0','1');");

@include("../../inc/footer.php");
?>