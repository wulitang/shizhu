<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `tieying_enewssearch`;");
E_C("CREATE TABLE `tieying_enewssearch` (
  `searchid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `keyboard` varchar(255) NOT NULL DEFAULT '',
  `searchtime` int(10) unsigned NOT NULL DEFAULT '0',
  `searchclass` varchar(255) NOT NULL DEFAULT '',
  `result_num` int(10) unsigned NOT NULL DEFAULT '0',
  `searchip` varchar(20) NOT NULL DEFAULT '',
  `classid` varchar(255) NOT NULL DEFAULT '',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `orderby` varchar(30) NOT NULL DEFAULT '0',
  `myorder` tinyint(1) NOT NULL DEFAULT '0',
  `checkpass` varchar(32) NOT NULL DEFAULT '',
  `tbname` varchar(60) NOT NULL DEFAULT '',
  `tempid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `iskey` tinyint(1) NOT NULL DEFAULT '0',
  `andsql` text NOT NULL,
  `trueclassid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`searchid`),
  KEY `checkpass` (`checkpass`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=gbk");
E_D("replace into `tieying_enewssearch` values('1','2015��','1432745322','title','1','183.206.162.211','','1','newstime','0','2c967acfe741b890eafbbbbfb7effb13','shop','1','0',' and ((title LIKE ''%2015��%''))','0');");
E_D("replace into `tieying_enewssearch` values('2','2015','1433847674','title','2','183.206.162.211','','11','newstime','0','9f016827aaaea9f723e69a2c2fc6c52f','shop','1','0',' and ((title LIKE ''%2015%''))','0');");
E_D("replace into `tieying_enewssearch` values('3','2015','1432807901','title','1','183.206.162.211','28','1','newstime','0','9f50da5e1fae9beac62e0924b154b14e','shop','0','0',' and classid=''28'' and ((title LIKE ''%2015%''))','28');");
E_D("replace into `tieying_enewssearch` values('4','11111','1432808149','title','1','183.206.162.211','','1','newstime','0','96c0f1393d323ed4a67958e28e043510','download','1','0',' and ((title LIKE ''%11111%''))','0');");
E_D("replace into `tieying_enewssearch` values('5','����','1432808676','title','1','183.206.162.211','','1','newstime','0','f963501ae58d2bb9390dfa75197f7999','shop','1','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `tieying_enewssearch` values('6','����','1437715105','title','1','221.178.200.4','','2','newstime','0','6785457a17a03d94b25aacb8e73f01f2','shop','1','0',' and ((title LIKE ''%����%''))','0');");
E_D("replace into `tieying_enewssearch` values('7','ִҵҩʦ','1437819862','title','1','221.178.200.24','','1','newstime','0','697caf67958419471344b0153d8bc25e','shop','1','0',' and ((title LIKE ''%ִҵҩʦ%''))','0');");
E_D("replace into `tieying_enewssearch` values('8','��Ƶ��','1437870845','title','1','221.178.200.24','','1','newstime','0','66a895a52de84477f05e6f77ef3a7d33','shop','1','0',' and ((title LIKE ''%��Ƶ��%''))','0');");

@include("../../inc/footer.php");
?>